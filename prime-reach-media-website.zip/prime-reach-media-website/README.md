# Prime Reach Media website

A responsive one-page website built with plain HTML, CSS and JavaScript.

## Files
- `index.html` — page content
- `styles.css` — layout and styling
- `script.js` — mobile navigation and current year
- `assets/prime-reach-media-logo.png` — supplied company logo

## Before publishing
1. Open `index.html`.
2. Find `YOUR-EMAIL@example.com` and replace it with your business email address.
3. Update any wording or contact details as required.
4. Open `index.html` in a browser to preview the site.

## Publish with GitHub Pages
1. Create a new repository on GitHub, for example `prime-reach-media-website`.
2. Upload all the files and folders in this project (keep the `assets` folder).
3. In the repository, open **Settings → Pages**.
4. Under **Build and deployment**, choose **Deploy from a branch**.
5. Select branch **main** and folder **/(root)**, then click **Save**.
6. After GitHub Pages finishes publishing, it will show your website address in the Pages section.

You can later connect your own domain in **Settings → Pages → Custom domain**. Keep your domain's DNS settings and GitHub Pages instructions aligned.
